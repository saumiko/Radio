/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asif Mohaimen
 */
public class Data {
     byte[] targetData;
     int numBytesRead;

    public byte[] getTargetData() {
        return targetData;
    }

    public void setTargetData(byte[] targetData) {
        this.targetData = targetData;
    }

    public int getNumBytesRead() {
        return numBytesRead;
    }

    public void setNumBytesRead(int numBytesRead) {
        this.numBytesRead = numBytesRead;
    }

}
